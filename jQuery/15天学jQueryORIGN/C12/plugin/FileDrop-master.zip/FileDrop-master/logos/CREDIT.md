CamiloMM - author of the beautiful FileDrop logo.

http://camilomm.deviantart.com